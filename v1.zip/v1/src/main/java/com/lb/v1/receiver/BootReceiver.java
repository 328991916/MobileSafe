package com.lb.v1.receiver;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.lb.v1.utils.ConstantValue;
import com.lb.v1.utils.SpUtil;

public class BootReceiver extends BroadcastReceiver {
    private static final String tag = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        //throw new UnsupportedOperationException("Not yet implemented");
        Log.i(tag,"重启手机成功了,并且监听到了相应的广播......");
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS)== PackageManager.PERMISSION_GRANTED) {
            String simSerialNumber = tm.getSimSerialNumber() + "xxx";

            String sim_number = SpUtil.getString(context, ConstantValue.SIM_NUMBER,"");
            if (!simSerialNumber.equals(sim_number)) {
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage("18902215973",
                        null,"sim change!!!",null,null);
            }
        }
    }
}

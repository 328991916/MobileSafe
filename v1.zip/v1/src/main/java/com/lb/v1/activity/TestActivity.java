package com.lb.v1.activity;

import android.app.Activity;
import android.os.Bundle;

import com.lb.v1.R;

public class TestActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }
}

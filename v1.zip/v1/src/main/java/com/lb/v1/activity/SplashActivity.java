package com.lb.v1.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.FileProvider;
import android.text.TextUtils;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lb.v1.R;
import com.lb.v1.utils.ConstantValue;
import com.lb.v1.utils.SpUtil;
import com.lb.v1.utils.StreamUtil;
import com.lb.v1.utils.ToastUtil;

import org.json.JSONObject;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class SplashActivity extends Activity {
    private static final String TAG = "SplashActivity";
    //MainActivity中属性
    String[]permssions = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.INTERNET,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.RECEIVE_BOOT_COMPLETED,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.VIBRATE,
            Manifest.permission.SYSTEM_ALERT_WINDOW,
            Manifest.permission.PROCESS_OUTGOING_CALLS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.WRITE_CALL_LOG,
            Manifest.permission.READ_SMS,
            Manifest.permission.KILL_BACKGROUND_PROCESSES,
            Manifest.permission.INSTALL_SHORTCUT,
            Manifest.permission.GET_TASKS,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.GET_PACKAGE_SIZE,
            Manifest.permission.CLEAR_APP_CACHE
    };

    protected static final int UPDATE_VERSION =100 ;
    protected static final int ENTER_HOME =101 ;
    protected static final int ERROR =102 ;

    private TextView tv_version_name;
    private int mLocalVersionCode;
    private String mVersionDes;
    private String mDownloadUrl;

    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case UPDATE_VERSION:
                    showUpdateDialog();
                    break;
                case ENTER_HOME:
                    enterHome();
                    break;
                case ERROR:
                    ToastUtil.show(getApplicationContext(),"ERROR");
                    break;
            }
        }
    };
    private RelativeLayout rl_root;


    private void enterHome() {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    private void showUpdateDialog() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setIcon(R.drawable.ic_launcher).
                setTitle("UPDATE_VERSION").setMessage(mVersionDes);
        builder.setPositiveButton("Update now", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                downloadApk();
            }
        });
        builder.setNegativeButton("Later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                enterHome();
            }
        });
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                enterHome();
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void downloadApk() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "mobilesafe74.apk";
            RequestParams entity = new RequestParams();
            entity.setUri(mDownloadUrl);
            entity.setSaveFilePath(path);
            Callback.CommonCallback<File> callback = new Callback.CommonCallback<File>() {
                @Override
                public void onSuccess(File result) {
                    Log.i(TAG,"download APK successfully. file="+result.getAbsolutePath()+";"+result.getName());
                    installApk(result);
                }

                @Override
                public void onError(Throwable ex, boolean isOnCallback) {
                    Log.i(TAG,"fail to download APK,ex="+ex);
                }

                @Override
                public void onCancelled(CancelledException cex) {
                    Log.i(TAG,"download APK canceled");
                }

                @Override
                public void onFinished() {
                    Log.i(TAG,"download APK finished");
                }
            };
            x.http().get(entity,callback);
        }
    }

    private void installApk(File result) {
        try {
            //File file=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"update74.apk");
            File file=new File(Environment.getExternalStorageDirectory(),"mobilesafe74.apk");
            Uri apkUri= FileProvider.getUriForFile(getApplicationContext(),"com.lb.v1.fileprovider",file);

            //Intent intent=new Intent("android.intent.action.VIEW");
            Intent intent=new Intent(Intent.ACTION_VIEW);
            intent.addCategory("android.intent.category.DEFAULT");
            //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.setDataAndType(apkUri,"application/vnd.android.package-archive");

            startActivityForResult(intent,0);
        }catch (Exception e){
            Log.i(TAG,"installApk: error="+e.getMessage());
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        enterHome();
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_splash);

        //onCreate中加载完activity_main后申请
        ArrayList<String> needRequests = new ArrayList<>();
        for (String str : permssions) {
            int checkResult = checkSelfPermission(str);
            if (checkResult == PackageManager.PERMISSION_DENIED) {
                needRequests.add(str);
            }
        }
        if (needRequests.size() > 0) {
            requestPermissions(needRequests.toArray(new String[needRequests.size()]), 1);
        }


        initUI();
        initData();
        initAnimation();
        initDB();

        Log.i("TAG",
                "SpUtil.getBoolean(this,ConstantValue.HAS_SHORTCUT,false)="+SpUtil.getBoolean(this,ConstantValue.HAS_SHORTCUT,false));
        if (!SpUtil.getBoolean(this,ConstantValue.HAS_SHORTCUT,false)) {
            initShortCut();
        }

    }

    private void initShortCut() {
        Log.i("TAG","initShortCut");
        Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
        intent.putExtra(Intent.EXTRA_SHORTCUT_ICON,BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher));
        intent.putExtra(Intent.EXTRA_SHORTCUT_NAME,"黑马卫士");

        Intent shortCutIntent = new Intent("android.intent.action.HOME");
        shortCutIntent.addCategory("android.intent.category.DEFAULT");

        intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT,shortCutIntent);

        sendBroadcast(intent);
        SpUtil.putBoolean(this,ConstantValue.HAS_SHORTCUT,true);
    }

    private void initDB() {
        initAddressDB("address.db");
        initAddressDB("commonnum.db");
        initAddressDB("antivirus.db");
    }

    private void initAddressDB(String dbName) {
        File filesDir = getFilesDir();
        File file = new File(filesDir, dbName);
        if (file.exists()) {
            return;
        }
        InputStream inputStream=null;
        FileOutputStream fos=null;

        try {
            inputStream = getAssets().open(dbName);
            fos=new FileOutputStream(file);
            byte[] bs = new byte[1024];
            int temp=-1;
            while ((temp=inputStream.read(bs))!=-1){
                fos.write(bs,0,temp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (inputStream != null && fos!=null) {
                try {
                    inputStream.close();
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    private void initAnimation() {
        AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);
        alphaAnimation.setDuration(3000);
        rl_root.startAnimation(alphaAnimation);

    }

    private void initData() {
        tv_version_name.setText("Version Name: "+getVersionName());
        mLocalVersionCode=getVersionCode();

        if (SpUtil.getBoolean(this, ConstantValue.OPEN_UPDATE,false)) {
            checkVersion();
        }else {
            mHandler.sendEmptyMessageDelayed(ENTER_HOME,4000);
        }
    }

    private void checkVersion() {
        new Thread() {
                			public void run() {
                                Message msg = Message.obtain();
                                long startTime = System.currentTimeMillis();

                				try {
                					// [2.2]创建URL 对象指定我们要访问的 网址(路径)
                					URL url = new URL("http://192.168.1.102:8080/update74.json");

                					// [2.3]拿到httpurlconnection对象 用于发送或者接收数据
                					HttpURLConnection conn = (HttpURLConnection) url
                							.openConnection();
                					// [2.4]设置发送get请求
                					conn.setRequestMethod("GET");// get要求大写 默认就是get请求
                					// [2.5]设置请求超时时间
                					conn.setConnectTimeout(5000);
                					conn.setReadTimeout(5000);
                					// [2.6]获取服务器返回的状态码
                					int code = conn.getResponseCode();
                					// [2.7]如果code == 200 说明请求成功
                					if (code == 200) {
                						// [2.8]获取服务器返回的数据 是以流的形式返回的 由于把流转换成字符串是一个非常常见的操作
                						// 所以我抽出一个工具类(utils)
                						InputStream in = conn.getInputStream();
                                        String json = StreamUtil.streamToString(in);
                                        JSONObject jsonObject = new JSONObject(json);

                                        String versionName = jsonObject.getString("versionName");
                                        mVersionDes = jsonObject.getString("versionDes");
                                        String versionCode = jsonObject.getString("versionCode");
                                        mDownloadUrl = jsonObject.getString("downloadUrl");
                                        Log.i(TAG,"mDownloadUrl="+mDownloadUrl);

                                        if (mLocalVersionCode<Integer.parseInt(versionCode) && !TextUtils.isEmpty(mDownloadUrl)) {
                                            msg.what=UPDATE_VERSION;
                                        }else {
                                            msg.what=ENTER_HOME;
                                        }

                					}
                				} catch (Exception e) {
                					e.printStackTrace();
                					msg.what=ERROR;
                				}finally {
                                    long endTime = System.currentTimeMillis();
                                    long lastTime = endTime - startTime;
                                    if ( lastTime<4000) {
                                        try {
                                            Thread.sleep(4000-lastTime);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    mHandler.sendMessage(msg);
                                }

                			};
                		}.start();

    }
    private int getVersionCode() {
        PackageManager packageManager = getPackageManager();
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return 0;
    }

    private String getVersionName() {
        PackageManager packageManager = getPackageManager();
        try {
            PackageInfo packageInfo=packageManager.getPackageInfo(getPackageName(),0);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void initUI() {
        tv_version_name = (TextView)findViewById(R.id.tv_version_name);
        rl_root = (RelativeLayout) findViewById(R.id.rl_root);
    }
}

package com.lb.v1.service;

import android.app.ActivityManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;

import com.lb.v1.activity.EnterPsdActivity;
import com.lb.v1.db.dao.AppLockDao;

import java.util.List;

public class WatchDogService extends Service {
    private AppLockDao mDao;
    private boolean isWatch;
    private InnerReceiver mInnerReceiver;
    private String mSkipPackagename;
    private List<String> mPacknameList;
    private MyContentObserver mContentObserver;

    public WatchDogService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        //throw new UnsupportedOperationException("Not yet implemented");
        return null;
    }

    @Override
    public void onCreate() {
        mDao = AppLockDao.getInstance(this);
        isWatch = true;
        watch();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.SKIP");
        mInnerReceiver = new InnerReceiver();
        registerReceiver(mInnerReceiver,intentFilter);

        mContentObserver = new MyContentObserver(new Handler());
        getContentResolver().registerContentObserver(Uri.parse("content://applock/change"),true,mContentObserver);

        super.onCreate();
    }

    @Override
    public void onDestroy() {
        isWatch = false;

        if (mInnerReceiver != null) {
            unregisterReceiver(mInnerReceiver);
        }
        if (mContentObserver != null) {
            getContentResolver().unregisterContentObserver(mContentObserver);
        }

        super.onDestroy();
    }

    private void watch() {
        new Thread(){
            @Override
            public void run() {
                mPacknameList = mDao.findAll();
                while (isWatch){
                    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                    List<ActivityManager.RunningTaskInfo> runningTasks = am.getRunningTasks(1);
                    ActivityManager.RunningTaskInfo runningTaskInfo = runningTasks.get(0);
                    String packageName = runningTaskInfo.topActivity.getPackageName();

                    if (mPacknameList.contains(packageName)) {
                        if (!packageName.equals(mSkipPackagename)) {
                            Intent intent = new Intent(getApplicationContext(), EnterPsdActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("packagename",packageName);
                            startActivity(intent);
                        }
                    }
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    private class InnerReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            mSkipPackagename = intent.getStringExtra("packagename");
        }
    }
    class MyContentObserver extends ContentObserver{

        /**
         * Creates a content observer.
         *
         * @param handler The handler to run {@link #onChange} on, or null if none.
         */
        public MyContentObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {
            new Thread(){
                @Override
                public void run() {
                    mPacknameList = mDao.findAll();
                }
            }.start();
            super.onChange(selfChange);
        }
    }
}

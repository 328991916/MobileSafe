package com.lb.v1.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.lb.v1.R;

public class SDCacheClearActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView textView = new TextView(getApplicationContext());
        textView.setText("SDCacheClearActivity");
        setContentView(textView);
    }
}

package com.lb.v1.db.domain;

public class BlackNumberInfo {
    public String phone,mode;

    public BlackNumberInfo() {
    }

    public BlackNumberInfo(String phone, String mode) {
        this.phone = phone;
        this.mode = mode;
    }

    public String getPhone() {
        return phone;
    }

    public String getMode() {
        return mode;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @Override
    public String toString() {
        return "BlackNumberInfo{" +
                "phone='" + phone + '\'' +
                ", mode='" + mode + '\'' +
                '}';
    }
}

package com.lb.v1.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.lb.v1.R;
import com.lb.v1.db.dao.AddressDao;
import com.lb.v1.utils.ConstantValue;
import com.lb.v1.utils.SpUtil;

public class AddressService extends Service {
    public static final String tag = "AddressService";
    private TelephonyManager mTM;
    private MyPhoneStateListener mPhoneStateListener;
    private WindowManager mWM;
    private View mViewToast;
    private WindowManager.LayoutParams mParams = new WindowManager.LayoutParams();
    private TextView tv_toast;
    private int[] mDrawableIds;
    private String mAddress;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            tv_toast.setText(mAddress);
        }
    };
    private int mScreenHeight,mScreenWidth;
    private InnerOutCallReceiver mInnerOutCallReceiver;

    public AddressService() {
    }

    @Override
    public void onCreate() {
        mTM = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        mPhoneStateListener = new MyPhoneStateListener();
        mTM.listen(mPhoneStateListener,PhoneStateListener.LISTEN_CALL_STATE);
        mWM = (WindowManager) getSystemService(WINDOW_SERVICE);

        mScreenHeight = mWM.getDefaultDisplay().getHeight();
        mScreenWidth = mWM.getDefaultDisplay().getWidth();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_NEW_OUTGOING_CALL);
        mInnerOutCallReceiver = new InnerOutCallReceiver();
        registerReceiver(mInnerOutCallReceiver,intentFilter);
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        //throw new UnsupportedOperationException("Not yet implemented");
        return null;
    }

    private class MyPhoneStateListener extends PhoneStateListener{
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            switch (state){
                case TelephonyManager.CALL_STATE_IDLE:
                    Log.i(tag,"挂断电话,空闲了.......................");
                    if (mWM!=null && mViewToast!=null) {
                        mWM.removeView(mViewToast);
                    }
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    break;
                case TelephonyManager.CALL_STATE_RINGING:
                    Log.i(tag,"响铃了.......................");
                    showToast(incomingNumber);
                    break;
            }
            super.onCallStateChanged(state, incomingNumber);
        }
    }

    private void showToast(String incomingNumber) {
        final WindowManager.LayoutParams params = mParams;
        params.height = WindowManager.LayoutParams.WRAP_CONTENT;
        params.width = WindowManager.LayoutParams.WRAP_CONTENT;
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        params.format = PixelFormat.TRANSLUCENT;
        params.type = WindowManager.LayoutParams.TYPE_PHONE;
        params.setTitle("Toast");
        params.gravity = Gravity.LEFT+Gravity.TOP;
        mViewToast = View.inflate(this, R.layout.toast_view, null);
        tv_toast = (TextView) mViewToast.findViewById(R.id.tv_toast);

        mViewToast.setOnTouchListener(new View.OnTouchListener() {
            public int startX,startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        startX = (int) event.getRawX();
                        startY = (int) event.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        int moveX= (int) event.getRawX();
                        int moveY= (int) event.getRawY();

                        int disX = moveX - startX;
                        int disY = moveY - startY;

                        params.x+=disX;
                        params.y+=disY;

                        if (params.x<0) {
                            params.x=0;
                        }
                        if (params.y<0) {
                            params.y=0;
                        }
                        if (params.x>mScreenWidth-mViewToast.getWidth()) {
                            params.x=mScreenWidth-mViewToast.getWidth();
                        }
                        if (params.y>mScreenHeight-mViewToast.getHeight()-22) {
                            params.y=mScreenHeight-mViewToast.getHeight()-22;
                        }

                        mWM.updateViewLayout(mViewToast,params);

                        startX= (int) event.getRawX();
                        startY= (int) event.getRawY();

                        break;
                    case MotionEvent.ACTION_UP:
                        SpUtil.putInt(getApplicationContext(),ConstantValue.LOCATION_X,params.x);
                        SpUtil.putInt(getApplicationContext(),ConstantValue.LOCATION_Y,params.y);
                        break;
                }
                return true;
            }
        });

        params.x=SpUtil.getInt(getApplicationContext(),ConstantValue.LOCATION_X,0);
        params.y=SpUtil.getInt(getApplicationContext(),ConstantValue.LOCATION_Y,0);

        mDrawableIds = new int[]{
                R.color.call_locate_white,
                R.color.call_locate_orange,
                R.color.call_locate_blue,
                R.color.call_locate_gray,
                R.color.call_locate_green};
        int toastStyleIndex = SpUtil.getInt(getApplicationContext(), ConstantValue.TOAST_STYLE, 0);
        tv_toast.setBackgroundResource(mDrawableIds[toastStyleIndex]);
        mWM.addView(mViewToast,params);
        query(incomingNumber);
    }

    private void query(final String incomingNumber) {
           new Thread(){
               @Override
               public void run() {
                   mAddress = AddressDao.getAddress(incomingNumber);
                    mHandler.sendEmptyMessage(0);
               }
           }.start();
    }

    @Override
    public void onDestroy() {
        if (mTM != null && mPhoneStateListener !=null) {
            mTM.listen(mPhoneStateListener,PhoneStateListener.LISTEN_NONE);
        }
        if (mInnerOutCallReceiver != null) {
            unregisterReceiver(mInnerOutCallReceiver);
        }
        super.onDestroy();
    }

    private class InnerOutCallReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String phone = getResultData();
            showToast(phone);
        }
    }
}
